function similarity=linearKernel(xi,l)
	
	xi=xi(:);

	similarity=l*xi;
	
	